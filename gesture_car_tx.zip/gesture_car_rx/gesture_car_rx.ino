/*
  RECEIVER (v4 - Aggressive Clone Fix) - Vehicle Drive
  Hardware: Arduino Nano + nRF24L01 (via adapter) + L298N + 4 motors

  v4 FIXES (targeting begin() failure on RX):
  ────────────────────────────────────────────
  1. SPI clock slowed to 1MHz (clones fail at default 10MHz)
  2. Force-configure fallback: if begin() fails, manually init and
     try to use the radio anyway (some clones fail the test but work)
  3. Raw SPI diagnostic reads STATUS register directly
  4. 2-second boot delay for adapter voltage regulator
  5. CE pin power-cycle between retry attempts

  MOTOR WIRING:
  LEFT  motors -> L298N OUT1+OUT2: ENA=D5, IN1=D4, IN2=D3
  RIGHT motors -> L298N OUT3+OUT4: ENB=D6, IN3=D7, IN4=D8
  L298N 12V -> 7.4V-12V battery (SEPARATE from Nano supply)
  Common GND: Nano + battery + L298N

  nRF24L01 (adapter): VCC->5V, GND->GND,
    CE->D9, CSN->D10, SCK->D13, MOSI->D11, MISO->D12

  LIBRARY: RF24 by TMRh20
*/

#include <SPI.h>
#include <RF24.h>

// ─── Pin Definitions ───
#define CE_PIN   9
#define CSN_PIN  10
#define LED_PIN  2   // optional status LED

// Motor pins
#define ENA 5
#define IN1 4
#define IN2 3
#define ENB 6
#define IN3 7
#define IN4 8

// ─── KEY FIX: Slow SPI clock to 1MHz ───
// The default is 10MHz. Many clone nRF24L01 chips (Si24R1, BK2425)
// cannot sustain 10MHz SPI reliably, causing begin() to fail because
// the register readback gets corrupted at high speed.
RF24 radio(CE_PIN, CSN_PIN, 1000000);  // 1MHz SPI

const byte ADDRESS[6] = "00001";

// ─── Data Packet (must match TX exactly) ───
struct GestureData {
  int16_t pitch;
  int16_t roll;
  uint8_t txHealth;
  uint8_t seqNum;
};
GestureData data;

// ─── Tuning Constants ───
const int   ANGLE_LIMIT    = 30;
const int   MIN_SPEED      = 120;
const int   MAX_SPEED      = 255;
const uint8_t RF_CHANNEL   = 76;   // must match TX exactly

// ─── Failsafe ───
const unsigned long SIGNAL_TIMEOUT = 500;  // ms
unsigned long lastReceiveMs = 0;
bool linkLost = false;

// ─── Diagnostics ───
uint16_t rxCount       = 0;
uint32_t lastPrintMs   = 0;
uint8_t  lastSeqNum    = 0;
uint16_t missedPackets = 0;
bool     radioOK       = false;

// ─── Forward declarations ───
void initRadio();
void forceConfigRadio();
uint8_t rawSpiRead(uint8_t reg);
void printRadioDiag();
void drive(int pitch, int roll);
void moveForward(int speed);
void moveBackward(int speed);
void turnLeft(int speed);
void turnRight(int speed);
void stopMotors();

void setup() {
  Serial.begin(115200);

  // ── 2-second boot delay ──
  // The nRF24L01 adapter board's voltage regulator needs time to
  // stabilize. On the RX (car) side, the L298N motor driver also
  // shares the power rail, causing slower stabilization.
  delay(2000);

  Serial.println(F("\n════════════════════════════"));
  Serial.println(F("  RECEIVER v4 BOOT"));
  Serial.println(F("════════════════════════════"));

  // Optional status LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // ── Motor pins ──
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  stopMotors();
  Serial.println(F("[RX] Motors initialized - all stopped."));

  // ── Radio init ──
  initRadio();
  lastReceiveMs = millis();
}

// ════════════════════════════════════════
//  RAW SPI DIAGNOSTIC
//  Reads the nRF24L01 STATUS register (0x07) directly via SPI,
//  bypassing the RF24 library entirely.
//  Expected: 0x0E (power-on default) or 0x0x (some valid status)
//  Bad signs: 0x00 (module dead/not connected) or 0xFF (no MISO pull)
// ════════════════════════════════════════
uint8_t rawSpiRead(uint8_t reg) {
  digitalWrite(CSN_PIN, LOW);
  delayMicroseconds(10);
  SPI.transfer(reg & 0x1F);       // read command = register address
  uint8_t val = SPI.transfer(0xFF); // clock out the response
  digitalWrite(CSN_PIN, HIGH);
  delayMicroseconds(10);
  return val;
}

void initRadio() {
  Serial.println(F("[RX] Starting nRF24L01 init..."));
  Serial.println(F("[RX] SPI clock: 1MHz (slow mode for clone compatibility)"));

  // ── Initialize SPI explicitly ──
  SPI.begin();
  pinMode(CSN_PIN, OUTPUT);
  digitalWrite(CSN_PIN, HIGH);
  pinMode(CE_PIN, OUTPUT);
  digitalWrite(CE_PIN, LOW);
  delay(200);

  // ── Raw SPI diagnostic BEFORE begin() ──
  Serial.print(F("[RX] Raw SPI test - STATUS register: 0x"));
  uint8_t status = rawSpiRead(0x07);
  Serial.println(status, HEX);

  if (status == 0x00) {
    Serial.println(F("[RX] STATUS=0x00 -> Module not responding. Likely dead or VCC not connected."));
  } else if (status == 0xFF) {
    Serial.println(F("[RX] STATUS=0xFF -> MISO stuck HIGH. Check MISO wire (D12) or module is dead."));
  } else {
    Serial.print(F("[RX] STATUS=0x"));
    Serial.print(status, HEX);
    Serial.println(F(" -> SPI bus IS working! Module is alive."));
  }

  // ── Retry begin() up to 5 times with CE power-cycling ──
  bool radioFound = false;
  for (uint8_t attempt = 1; attempt <= 5; attempt++) {
    Serial.print(F("[RX] begin() attempt "));
    Serial.print(attempt);
    Serial.print(F("/5 ... "));

    // Power-cycle via CE pin between attempts
    if (attempt > 1) {
      digitalWrite(CE_PIN, LOW);
      delay(100);
      digitalWrite(CE_PIN, HIGH);
      delay(100);
      digitalWrite(CE_PIN, LOW);
      delay(200);
    }

    if (radio.begin()) {
      Serial.println(F("SUCCESS"));
      radioFound = true;
      break;
    } else {
      Serial.println(F("FAILED"));
      delay(500);
    }
  }

  if (radioFound) {
    // ── Normal configuration path ──
    configureRadio();
  } else {
    // ══════════════════════════════════════════════════════
    //  FORCE-CONFIGURE FALLBACK
    //  Some clone chips (Si24R1, BK2425) fail the begin()
    //  register readback test but STILL WORK for RX/TX.
    //  We bypass the check and force-configure anyway.
    // ══════════════════════════════════════════════════════
    Serial.println(F("[RX] begin() failed 5 times."));

    if (status != 0x00 && status != 0xFF) {
      // SPI bus works (raw test passed) but begin() disagrees
      Serial.println(F("[RX] BUT raw SPI test showed the module IS alive!"));
      Serial.println(F("[RX] Attempting FORCE CONFIGURE (bypassing begin() check)..."));
      forceConfigRadio();
    } else {
      // SPI bus is truly dead
      Serial.println(F("╔══════════════════════════════════════════════╗"));
      Serial.println(F("║  FATAL: nRF24L01 NOT DETECTED ON SPI BUS   ║"));
      Serial.println(F("║  Raw SPI test also failed.                  ║"));
      Serial.println(F("║                                              ║"));
      Serial.println(F("║  This is a HARDWARE problem:                 ║"));
      Serial.println(F("║  - Swap this module with the working TX one ║"));
      Serial.println(F("║  - Check all 7 wires                        ║"));
      Serial.println(F("║  - Add 10uF cap across VCC-GND              ║"));
      Serial.println(F("║  - Try powering nRF from separate 3.3V      ║"));
      Serial.println(F("╚══════════════════════════════════════════════╝"));
      radioOK = false;

      // DON'T halt - keep retrying in loop()
      return;
    }
  }
}

void configureRadio() {
  delay(150);

  radio.setChannel(RF_CHANNEL);
  radio.setPALevel(RF24_PA_LOW);
  radio.setDataRate(RF24_1MBPS);
  radio.setAutoAck(true);
  radio.setRetries(5, 15);
  radio.setCRCLength(RF24_CRC_16);
  radio.setPayloadSize(sizeof(GestureData));
  radio.openReadingPipe(0, ADDRESS);

  radio.powerUp();
  delay(150);

  radio.flush_tx();
  radio.flush_rx();
  radio.startListening();

  // Verify
  uint8_t ch = radio.getChannel();
  if (ch != RF_CHANNEL) {
    Serial.print(F("[RX] Channel verify FAILED. Got: "));
    Serial.println(ch);
    radioOK = false;
  } else {
    Serial.println(F("[RX] Channel register verified OK."));
    radioOK = true;
  }

  printRadioDiag();
}

// ════════════════════════════════════════
//  FORCE CONFIGURE (bypass begin() failure)
//  Manually writes nRF24L01 registers via SPI
//  when the RF24 library's begin() check fails
//  but raw SPI communication works.
// ════════════════════════════════════════
void forceConfigRadio() {
  // Try calling the library functions directly even though begin() failed.
  // The RF24 library still has internal state from the failed begin().
  // On many clones, the library functions still work despite begin() returning false.

  radio.setChannel(RF_CHANNEL);
  radio.setPALevel(RF24_PA_LOW);
  radio.setDataRate(RF24_1MBPS);
  radio.setAutoAck(true);
  radio.setRetries(5, 15);
  radio.setCRCLength(RF24_CRC_16);
  radio.setPayloadSize(sizeof(GestureData));
  radio.openReadingPipe(0, ADDRESS);
  radio.powerUp();
  delay(200);
  radio.flush_tx();
  radio.flush_rx();
  radio.startListening();

  // Verify if force-config actually worked
  uint8_t ch = radio.getChannel();
  Serial.print(F("[RX] Force-config channel readback: "));
  Serial.println(ch);

  if (ch == RF_CHANNEL) {
    Serial.println(F("[RX] FORCE CONFIG SUCCEEDED! Radio is working."));
    radioOK = true;
    printRadioDiag();
  } else {
    Serial.println(F("[RX] Force config failed. Channel mismatch."));
    Serial.println(F("[RX] Will keep retrying in loop..."));
    radioOK = false;
  }
}

void printRadioDiag() {
  Serial.println(F("\n── Radio Configuration ──"));
  Serial.print(F("  Channel:    ")); Serial.println(radio.getChannel());
  Serial.print(F("  PA Level:   "));
  switch (radio.getPALevel()) {
    case RF24_PA_MIN:  Serial.println(F("MIN (-18dBm)")); break;
    case RF24_PA_LOW:  Serial.println(F("LOW (-12dBm)")); break;
    case RF24_PA_HIGH: Serial.println(F("HIGH (-6dBm)")); break;
    case RF24_PA_MAX:  Serial.println(F("MAX (0dBm)")); break;
  }
  Serial.print(F("  Data Rate:  "));
  switch (radio.getDataRate()) {
    case RF24_250KBPS: Serial.println(F("250 KBPS")); break;
    case RF24_1MBPS:   Serial.println(F("1 MBPS")); break;
    case RF24_2MBPS:   Serial.println(F("2 MBPS")); break;
  }
  Serial.print(F("  CRC:        "));
  switch (radio.getCRCLength()) {
    case RF24_CRC_DISABLED: Serial.println(F("Disabled")); break;
    case RF24_CRC_8:        Serial.println(F("8-bit")); break;
    case RF24_CRC_16:       Serial.println(F("16-bit")); break;
  }
  Serial.print(F("  Payload:    ")); Serial.print(sizeof(GestureData)); Serial.println(F(" bytes"));
  Serial.println(F("─────────────────────────\n"));
  Serial.println(F("[RX] Waiting for transmitter..."));
}

void loop() {
  if (!radioOK) {
    static uint32_t lastRetry = 0;
    if (millis() - lastRetry > 5000) {
      lastRetry = millis();
      Serial.println(F("[RX] Retrying radio init..."));
      initRadio();
    }
    stopMotors();
    return;
  }

  // ── Check for incoming data ──
  if (radio.available()) {
    radio.read(&data, sizeof(data));
    lastReceiveMs = millis();
    rxCount++;

    // ── Detect missed packets via sequence number ──
    uint8_t expectedSeq = lastSeqNum + 1;
    if (data.seqNum != expectedSeq && rxCount > 1) {
      uint8_t gap = data.seqNum - expectedSeq;
      missedPackets += gap;
    }
    lastSeqNum = data.seqNum;

    // ── Link restored notification ──
    if (linkLost) {
      linkLost = false;
      Serial.println(F("[RX] LINK RESTORED"));
    }

    // ── Status LED on ──
    digitalWrite(LED_PIN, HIGH);

    // ── Drive only if TX health byte is valid ──
    if (data.txHealth == 0xFF) {
      drive(data.pitch, data.roll);
    } else {
      Serial.print(F("[RX] Bad TX health: 0x"));
      Serial.println(data.txHealth, HEX);
      stopMotors();
    }
  }

  // ── Failsafe: stop motors if signal lost ──
  if (!linkLost && (millis() - lastReceiveMs > SIGNAL_TIMEOUT)) {
    linkLost = true;
    stopMotors();
    digitalWrite(LED_PIN, LOW);
    Serial.println(F("[RX] FAILSAFE: Signal lost > 500ms. Motors STOPPED."));
  }

  // ── Periodic diagnostics every 2 seconds ──
  if (millis() - lastPrintMs >= 2000) {
    lastPrintMs = millis();

    if (linkLost) {
      Serial.println(F("[RX] Still no signal from TX. Waiting..."));
    } else {
      Serial.print(F("[RX] Packets/2s: ")); Serial.print(rxCount);
      Serial.print(F("  Missed: "));        Serial.print(missedPackets);
      Serial.print(F("  Last P:")); Serial.print(data.pitch);
      Serial.print(F(" R:"));      Serial.println(data.roll);
    }

    rxCount       = 0;
    missedPackets = 0;
  }
}

// ════════════════════════════════════════
//  DRIVE LOGIC
// ════════════════════════════════════════

void drive(int pitch, int roll) {
  if (pitch == 0 && roll == 0) {
    stopMotors();
    return;
  }

  if (abs(pitch) >= abs(roll)) {
    int spd = constrain(
      map(abs(pitch), 0, ANGLE_LIMIT, MIN_SPEED, MAX_SPEED),
      MIN_SPEED, MAX_SPEED
    );
    if (pitch > 0) moveForward(spd);
    else           moveBackward(spd);
  } else {
    int spd = constrain(
      map(abs(roll), 0, ANGLE_LIMIT, MIN_SPEED, MAX_SPEED),
      MIN_SPEED, MAX_SPEED
    );
    if (roll > 0) turnRight(spd);
    else          turnLeft(spd);
  }
}

// ════════════════════════════════════════
//  MOTOR PRIMITIVES
// ════════════════════════════════════════

void moveForward(int speed) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);  analogWrite(ENA, speed);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);  analogWrite(ENB, speed);
}

void moveBackward(int speed) {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH); analogWrite(ENA, speed);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH); analogWrite(ENB, speed);
}

void turnLeft(int speed) {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH); analogWrite(ENA, speed);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);  analogWrite(ENB, speed);
}

void turnRight(int speed) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);  analogWrite(ENA, speed);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH); analogWrite(ENB, speed);
}

void stopMotors() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW); analogWrite(ENA, 0);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW); analogWrite(ENB, 0);
}
