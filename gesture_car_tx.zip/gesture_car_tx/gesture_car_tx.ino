/*
  TRANSMITTER (v2 - Clone-Proof) - Gesture Controller
  Hardware: Arduino Nano + MPU6050 + nRF24L01 (via adapter)

  ROOT CAUSE FIXES (v2):
  ──────────────────────
  1. PA level → RF24_PA_LOW  (clones + Nano 3.3V can't sustain PA_HIGH)
  2. Data rate → 1MBPS       (250KBPS fails on most clones)
  3. Channel → 76            (above WiFi but within reliable clone range)
  4. Added 150ms settle after begin() and powerUp()
  5. TX FIFO flushed on every failed write (prevents FIFO lockup)
  6. CSN pin driven HIGH before begin() to isolate SPI bus
  7. Full register dump on boot for debugging
  8. Heartbeat LED on pin 2 (optional - connect LED+220Ω to D2)

  WIRING (unchanged):
  MPU6050: VCC→5V, GND→GND, SCL→A5, SDA→A4
  nRF24L01 (adapter): VCC→5V, GND→GND,
    CE→D9, CSN→D10, SCK→D13, MOSI→D11, MISO→D12

  CRITICAL HARDWARE FIX:
  Solder a 10µF electrolytic capacitor directly across the nRF24L01
  module's VCC and GND pins. This is the #1 fix for flaky modules.

  LIBRARIES: RF24 by TMRh20 | MPU6050_tockn by tockn
*/

#include <Wire.h>
#include <MPU6050_tockn.h>
#include <SPI.h>
#include <RF24.h>

// ─── Pin Definitions ───
#define CE_PIN   9
#define CSN_PIN  10
#define LED_PIN  2   // optional heartbeat LED

MPU6050 mpu6050(Wire);
RF24 radio(CE_PIN, CSN_PIN, 1000000);  // 1MHz SPI - matches RX

const byte ADDRESS[6] = "00001";

// ─── Data Packet ───
struct GestureData {
  int16_t pitch;
  int16_t roll;
  uint8_t txHealth;   // 0xFF = alive, 0x00 = fault
  uint8_t seqNum;     // rolling sequence number for RX to detect gaps
};
GestureData data;

// ─── Tuning Constants ───
const int   ANGLE_LIMIT  = 30;
const int   DEADZONE     = 5;
const uint8_t RF_CHANNEL = 76;   // 2.476GHz - above WiFi, within clone range

// ─── Diagnostics ───
uint16_t failCount   = 0;
uint16_t sendCount   = 0;
uint32_t lastPrintMs = 0;
uint8_t  seqNum      = 0;
bool     radioOK     = false;

// ─── Forward declarations ───
void initRadio();
void printRadioDiag();

void setup() {
  Serial.begin(115200);

  // ── CRITICAL: Let nRF24L01 voltage regulator stabilize after power-on ──
  // Without this, the module is not ready for SPI when begin() runs.
  delay(1000);

  Serial.println(F("\n════════════════════════════"));
  Serial.println(F("  TRANSMITTER v3 BOOT"));
  Serial.println(F("════════════════════════════"));

  // Optional heartbeat LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // ── DO NOT touch CSN/CE pins manually - let RF24 library handle them ──

  // ── MPU6050 init (I2C - no SPI conflict) ──
  Wire.begin();
  mpu6050.begin();
  Serial.println(F("[TX] MPU6050 found. Calibrating - keep sensor FLAT and STILL..."));
  mpu6050.calcGyroOffsets(true);
  Serial.println(F("[TX] MPU6050 calibration done.\n"));

  // ── Radio init ──
  initRadio();

  data.txHealth = 0xFF;
  data.seqNum   = 0;
}

void initRadio() {
  Serial.println(F("[TX] Starting nRF24L01 init..."));

  // ── Explicitly initialize SPI before RF24 ──
  SPI.begin();
  delay(100);

  // ── Retry begin() up to 5 times ──
  // Clone chips and adapter boards often fail the first SPI handshake
  // but succeed after a short delay + retry.
  bool radioFound = false;
  for (uint8_t attempt = 1; attempt <= 5; attempt++) {
    Serial.print(F("[TX] begin() attempt "));
    Serial.print(attempt);
    Serial.print(F("/5 ... "));

    if (radio.begin()) {
      Serial.println(F("SUCCESS"));
      radioFound = true;
      break;
    } else {
      Serial.println(F("FAILED"));
      delay(500);  // give module time to recover before retry
    }
  }

  if (!radioFound) {
    Serial.println(F("╔══════════════════════════════════════════════╗"));
    Serial.println(F("║  FATAL: nRF24L01 NOT DETECTED ON SPI BUS   ║"));
    Serial.println(F("║  after 5 attempts.                          ║"));
    Serial.println(F("║                                              ║"));
    Serial.println(F("║  Check these things:                         ║"));
    Serial.println(F("║  1. CE  -> D9,  CSN -> D10                  ║"));
    Serial.println(F("║  2. SCK -> D13, MOSI -> D11, MISO -> D12   ║"));
    Serial.println(F("║  3. VCC -> 5V (if using adapter board)      ║"));
    Serial.println(F("║     VCC -> 3.3V (if NO adapter board)       ║"));
    Serial.println(F("║  4. GND -> GND (shared with Nano)           ║"));
    Serial.println(F("║  5. 10uF cap across VCC-GND of module       ║"));
    Serial.println(F("║  6. Try a DIFFERENT nRF24L01 module          ║"));
    Serial.println(F("╚══════════════════════════════════════════════╝"));
    radioOK = false;

    // Blink LED rapidly to indicate failure
    while (1) {
      digitalWrite(LED_PIN, !digitalRead(LED_PIN));
      delay(200);
    }
  }

  // ── Critical: let PLL and oscillator settle after begin() ──
  delay(150);

  radio.setChannel(RF_CHANNEL);
  radio.setPALevel(RF24_PA_LOW);        // LOW = most stable on clones + weak PSU
  radio.setDataRate(RF24_1MBPS);        // 1MBPS = most reliable on clone hardware
  radio.setAutoAck(true);
  radio.setRetries(5, 15);             // 5 = (5+1)*250µs = 1.5ms delay, 15 retries
  radio.setCRCLength(RF24_CRC_16);     // 16-bit CRC for data integrity
  radio.setPayloadSize(sizeof(GestureData));  // fixed payload = faster
  radio.openWritingPipe(ADDRESS);
  radio.stopListening();

  // ── Power up and settle again ──
  radio.powerUp();
  delay(150);

  // ── Flush any stale data in FIFOs ──
  radio.flush_tx();
  radio.flush_rx();

  // ── Verify channel was written correctly ──
  uint8_t ch = radio.getChannel();
  if (ch != RF_CHANNEL) {
    Serial.print(F("[TX] ⚠ CHANNEL VERIFY FAILED. Expected: "));
    Serial.print(RF_CHANNEL);
    Serial.print(F("  Got: "));
    Serial.println(ch);
    Serial.println(F("[TX] This usually means the SPI bus is unreliable."));
    radioOK = false;
  } else {
    Serial.println(F("[TX] ✓ Channel register verified OK."));
    radioOK = true;
  }

  // ── Print full config ──
  printRadioDiag();
}

void printRadioDiag() {
  Serial.println(F("\n── Radio Configuration ──"));
  Serial.print(F("  Channel:    ")); Serial.println(radio.getChannel());
  Serial.print(F("  PA Level:   "));
  switch (radio.getPALevel()) {
    case RF24_PA_MIN:  Serial.println(F("MIN (-18dBm)")); break;
    case RF24_PA_LOW:  Serial.println(F("LOW (-12dBm)")); break;
    case RF24_PA_HIGH: Serial.println(F("HIGH (-6dBm)")); break;
    case RF24_PA_MAX:  Serial.println(F("MAX (0dBm)")); break;
  }
  Serial.print(F("  Data Rate:  "));
  switch (radio.getDataRate()) {
    case RF24_250KBPS: Serial.println(F("250 KBPS")); break;
    case RF24_1MBPS:   Serial.println(F("1 MBPS")); break;
    case RF24_2MBPS:   Serial.println(F("2 MBPS")); break;
  }
  Serial.print(F("  CRC:        "));
  switch (radio.getCRCLength()) {
    case RF24_CRC_DISABLED: Serial.println(F("Disabled")); break;
    case RF24_CRC_8:        Serial.println(F("8-bit")); break;
    case RF24_CRC_16:       Serial.println(F("16-bit")); break;
  }
  Serial.print(F("  Payload:    ")); Serial.print(sizeof(GestureData)); Serial.println(F(" bytes"));
  Serial.println(F("─────────────────────────\n"));
}

void loop() {
  if (!radioOK) {
    // If radio init failed verification, try re-init every 3 seconds
    static uint32_t lastRetry = 0;
    if (millis() - lastRetry > 3000) {
      lastRetry = millis();
      Serial.println(F("[TX] Retrying radio init..."));
      initRadio();
    }
    return;
  }

  mpu6050.update();

  float rawPitch = mpu6050.getAngleY();
  float rawRoll  = mpu6050.getAngleX();

  // ── Deadzone ──
  if (fabs(rawPitch) < DEADZONE) rawPitch = 0;
  if (fabs(rawRoll)  < DEADZONE) rawRoll  = 0;

  // ── Clamp and pack ──
  data.pitch    = constrain((int)rawPitch, -ANGLE_LIMIT, ANGLE_LIMIT);
  data.roll     = constrain((int)rawRoll,  -ANGLE_LIMIT, ANGLE_LIMIT);
  data.txHealth = 0xFF;
  data.seqNum   = seqNum++;

  // ── Transmit ──
  bool ok = radio.write(&data, sizeof(data));
  sendCount++;

  if (!ok) {
    failCount++;
    // CRITICAL FIX: Flush TX FIFO after failure to prevent lockup
    radio.flush_tx();
  }

  // ── Heartbeat LED: solid = sending OK, off = failing ──
  digitalWrite(LED_PIN, ok ? HIGH : LOW);

  // ── Diagnostics every 1 second ──
  if (millis() - lastPrintMs >= 1000) {
    lastPrintMs = millis();

    uint8_t successRate = (sendCount > 0)
                          ? (uint8_t)(((uint32_t)(sendCount - failCount) * 100UL) / sendCount)
                          : 0;

    Serial.print(F("[TX] P:")); Serial.print(data.pitch);
    Serial.print(F(" R:"));     Serial.print(data.roll);
    Serial.print(F(" | Link:")); Serial.print(successRate); Serial.print(F("%"));
    Serial.print(F(" ("));      Serial.print(sendCount - failCount);
    Serial.print(F("/"));       Serial.print(sendCount); Serial.print(F(")"));

    if (successRate == 0) {
      Serial.println(F("  ⚠ NO ACK - check RX power/wiring"));
    } else if (successRate < 50) {
      Serial.println(F("  ⚠ WEAK LINK"));
    } else {
      Serial.println(F("  ✓ OK"));
    }

    // Reset counters each window
    failCount  = 0;
    sendCount  = 0;
  }

  delay(20);  // ~50 packets/sec
}
